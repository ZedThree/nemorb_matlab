%
% Gets one time slice multi-dim data set in HDF5 "CRPP standard format result file".
%
%  [data, time, text, PlotOrder] = vismd_GetDataSet2(FileName, dim, DataSetName, i_frame);
%
% INPUTS: 
%   FileName    : HDF5 file name
%   dim         : = '1d' (resp. '2d') for 1-dim (resp. 2-dim) variables.
%   DataSetName : Name of 0-dim data set (without path over group hierarchy)
%   i_frame     : Index of time frame
%
% OUTPUTS:
%   data : Actual data values for all times
%   text : Title string attribute of dataset 
%   PlotOrder : Integer attribute defining plotting order
% 

function [data, time, text, PlotOrder] = vismd_GetDataSet2(FileName, dim, DataSetName, i_frame)

GroupName = ['/data/var', dim, '/', DataSetName,'/data'];

file = H5F.open(FileName, 'H5F_ACC_RDONLY', 'H5P_DEFAULT');

try
   tm = H5G.get_objinfo(file, GroupName,0);
catch
   % If the 'data' group doesn't exist, this must in the old format
   % with each time slice stored separately. 
   H5F.close(file);
   [data, time, text, PlotOrder] = vismd_GetDataSet(FileName, dim, DataSetName, i_frame);
   return;
end

datatypeID = H5T.copy('H5T_NATIVE_DOUBLE');

dataset = H5D.open(file, GroupName);
dataspace = H5D.get_space(dataset);    

[rank, dims_out] = H5S.get_simple_extent_dims(dataspace);

rank = size(dims_out,1);
offset = [[(i_frame-1)] zeros(1,rank-1)];
count =  [[1] transpose( dims_out(2:end)) ];

%fprintf('\nMatrix X: \nRank= %i\nDimensions= %i x %i x %i \n', rank, dims_out(1), dims_out(2), dims_out(3))
%fprintf('\n\nReading subset %i x %i x %i from X with offset [%i, %i, %i]\n', ...
%	count(1), count(2), count(3), offset(1), offset(2), offset(3))

H5S.select_hyperslab(dataspace, 'H5S_SELECT_SET', offset, [], count, []);
memspace = H5S.create_simple(rank, count, []);   

%text='readdata'
data2 = H5D.read(dataset, 'H5ML_DEFAULT', memspace, dataspace, 'H5P_DEFAULT');
data  = squeeze(data2);
%size(data);
%text='~readdata'

H5S.close(dataspace);
H5D.close(dataset);
H5S.close(memspace);
H5F.close(file);

if nargout > 1, 
  % Get time attribute: should 
  TimeName = ['/data/var', dim, '/', DataSetName,'/time'];
  timearray = hdf5read(FileName, TimeName);
  time = timearray(i_frame);
end

if nargout > 2,
  % Get title string attribute
  AttrName = [GroupName, '/title'];		 
  attr = hdf5read(FileName, AttrName);
  text = attr.Data;
end

if nargout > 3,
  % Get PlotOrder integer attribute
  AttrName = [GroupName, '/PlotOrder'];		 
  PlotOrder = hdf5read(FileName, AttrName);
end

