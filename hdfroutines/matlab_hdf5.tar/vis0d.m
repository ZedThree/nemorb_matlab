%
%  Plots averages (0-dim data) over the system in time.
%  Assumes HDF5 "CRPP standard format result file".
%
% Invoke with basic command
%   > vis0d(RES_filename)
% where RES_filename is the HDF5 result file name.
%
% OPTIONAL arguments:
%     * To plot only a sample of variables:
%         > vis0d(..., 'vars', SampleNameList)
%       where SampleNameList is a cell array of variable names.
%     * To plot only a limited time interval:
%         > vis0d(..., 'TimeInt', [t1, t2])
%  
%----------------------------------------------------------------------

function vis0d(RES_filename, varargin)

l_TimeInt    = false;
l_SampleVars = false;


% Identify optional arguments
iarg = 1;
while iarg < length(varargin),
  switch varargin{iarg},
  case 'vars',
    l_SampleVars = true;
    SampleNameList = varargin{iarg+1};
  case 'TimeInt',
    l_TimeInt = true;
    TimeInt = varargin{iarg+1};
  otherwise,
    disp('Bad argument syntax')
    return
  end
  iarg = iarg + 2;
end


% Get HDF5 file info
h5_info = hdf5info(RES_filename);


% 0-dim time mesh data
try
    [tm, attr] = hdf5read(RES_filename, '/data/var0d/time', 'ReadAttributes', true);
    attr = hdf5read(RES_filename, ['data/var0d/time/title']);
catch
    [tm, attr] = hdf5read(RES_filename, '/data/var0d/time_', 'ReadAttributes', true);
    attr = hdf5read(RES_filename, ['data/var0d/time_/title']);
end
t_text = attr.Data
%keyboard
%t_text = attr.Value.Data;

% Identify time interval
if l_TimeInt,
  it_i = interp1(tm, 1:length(tm), max(TimeInt(1), tm(1))  , 'nearest');
  it_f = interp1(tm, 1:length(tm), min(TimeInt(2), tm(end)), 'nearest');
else
  it_i = 1;
  it_f = length(tm);
end


% --- find all 0-dim variables
FullNameList = vis0d_GetVarNames(h5_info.GroupHierarchy)

if l_SampleVars,
  % Identify variables from sample name list in full name list
  if ~iscell(SampleNameList),
    if ischar(SampleNameList),
      SampleNameList = cellstr(SampleNameList);
    else
      fprintf('Name list of sample variables must be character or cell string\n')
      return
    end
  end

  NameList = [];
  for iv = 1:length(SampleNameList),
    name = char(SampleNameList(iv));
    if isempty(strmatch(name, FullNameList, 'exact')),
      fprintf('!!! %s is not in list of 0-dim variables !!!\n', name)
    else	  
      NameList{end+1} = name;
    end	      
  end
else
  % Consider all 0-dim variables
  NameList = FullNameList;
end

n_var0d = length(NameList)

for iv = 1:n_var0d,
  VarName = char(NameList(iv));
  [data, text, PlotOrder(iv)] = vis0d_GetDataSet(RES_filename, VarName);

  vars(iv).data = data;
  vars(iv).text = text;
end

PlotOrder

% Order variables for plotting
[dummy, ind_sort] = sort(PlotOrder);

vars = vars(ind_sort);

%--- initializing 

n_hor = round(sqrt(n_var0d)) ; % number of horizontal plots
n_ver = ceil(n_var0d/n_hor) ;    % number of vertical plots

%--- plots
figure

for iv = 1:n_var0d,
  subplot(n_ver, n_hor, iv)

  y = vars(iv).data(it_i:it_f);
  plot(tm(it_i:it_f), y, '-')

  y_min = min(y);
  y_max = max(y);

  if (y_min < y_max) 
    dlta_y = 0.2*(y_max - y_min);
    y_min = y_min - dlta_y;
    y_max = y_max + dlta_y;
    set(gca, 'YLim', [y_min, y_max])
  end

  xlabel(t_text); ylabel(vars(iv).text);
  
end

is = findstr(RES_filename, '/');
if size(is, 2) <= 2
  title_filename = RES_filename;
else
  title_filename = RES_filename(is(end-2)+1:end);
end

subplot(n_ver, n_hor, round(n_hor/2))
title(title_filename, 'Interpreter', 'none')


