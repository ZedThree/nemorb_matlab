%
% Gets multi-dim data set in HDF5 "CRPP standard format result file".
%
%  [data, time, text, PlotOrder] = vismd_GetDataSet(FileName, dim, DataSetName, i_frame);
%
% INPUTS: 
%   FileName    : HDF5 file name
%   dim         : = '1d' (resp. '2d') for 1-dim (resp. 2-dim) variables.
%   DataSetName : Name of data set (without path over group hierarchy)
%   i_frame     : Index of time frame
%
% OUTPUTS:
%   data : Actual data values for all times
%   text : Title string attribute of dataset 
%   PlotOrder : Integer attribute defining plotting order
% 

function [data, time, text, PlotOrder] = vismd_GetDataSet(FileName, dim, DataSetName, i_frame);

GroupName = ['/data/var', dim, '/', DataSetName];

TimeFrameName = [GroupName, num2str(i_frame, '/%06i')];

% Get data

% Earlier versions of matlab transpose the array when they
% read it from the hdf5 file.
if  isempty(findstr(version,'7.1.0'))==1,
    data = hdf5read(FileName, TimeFrameName);
else
    data = transpose(hdf5read(FileName, TimeFrameName));    
end

if nargout > 1, 
  % Get time attribute
  AttrName = [TimeFrameName, '/time']; 
  time = hdf5read(FileName, AttrName);
end

if nargout > 2,
  % Get title string attribute
  AttrName = [GroupName, '/title'];		 
  attr = hdf5read(FileName, AttrName);
  text = attr.Data;
end

if nargout > 3,
  % Get PlotOrder integer attribute
  AttrName = [GroupName, '/PlotOrder'];		 
  PlotOrder = hdf5read(FileName, AttrName);
end
